<?php
include 'db_connect.php';
header("Content-Type: application/json; charset=utf-8");
ini_set('display_errors',1); error_reporting(E_ALL);

// ===== created_by 컬럼 체크/추가 =====
$check = $conn->query("SHOW COLUMNS FROM brainstorm_space LIKE 'created_by'");
if($check->num_rows === 0){
    $conn->query("ALTER TABLE brainstorm_space ADD COLUMN created_by INT NOT NULL DEFAULT 1");
}

// POST 체크
if($_SERVER["REQUEST_METHOD"] !== "POST"){
    echo json_encode(["status"=>"error","msg"=>"POST 요청 아님"]);
    exit;
}

// 클라이언트에서 넘어온 action과 author_id
$action = $_POST['action'] ?? '';
$author_id = $_POST['author_id'] ?? 1; // 테스트용 기본 1

// ===== 기본 팀 생성 =====
$teamResult = $conn->query("SELECT id FROM team LIMIT 1");
if($teamResult->num_rows>0) {
    $team_id = $teamResult->fetch_assoc()['id'];
} else {
    $conn->query("INSERT INTO team(name,created_by) VALUES('default_team',NULL)");
    $team_id = $conn->insert_id;
}

// ===== 유저별 개인 공간 생성/조회 =====
$spaceRes = $conn->prepare("
    SELECT id FROM brainstorm_space 
    WHERE team_id=? AND created_by=? LIMIT 1
");
$spaceRes->bind_param("ii", $team_id, $author_id);
$spaceRes->execute();
$spaceRes = $spaceRes->get_result();

if($spaceRes->num_rows>0) {
    $space_id = $spaceRes->fetch_assoc()['id'];
} else {
    $topic = "개인 공간";
    $stmt = $conn->prepare("
        INSERT INTO brainstorm_space(team_id, topic, created_by, created_at) 
        VALUES (?, ?, ?, NOW())
    ");
    $stmt->bind_param("isi", $team_id, $topic, $author_id);
    $stmt->execute();
    $space_id = $stmt->insert_id;
}

// ===== 메시지 추가 =====
if($action === "add"){
    $content = $_POST['content'] ?? '';
    $category = $_POST['category'] ?? '아이디어';
    $color = $_POST['color'] ?? 'color-yellow';
    $posX = $_POST['posX'] ?? 100;
    $posY = $_POST['posY'] ?? 100;

    if(empty($content)){
        echo json_encode(["status"=>"error","msg"=>"내용 없음"]);
        exit;
    }

    $stmt = $conn->prepare("
        INSERT INTO brainstorm_message(space_id, author_id, content, category, color, posX, posY, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
    ");
    $stmt->bind_param("iisssii", $space_id, $author_id, $content, $category, $color, $posX, $posY);

    if($stmt->execute()) echo json_encode(["status"=>"success"]);
    else echo json_encode(["status"=>"error","msg"=>$stmt->error]);

// ===== 메시지 불러오기 =====
} else if($action === "load"){
    $stmt = $conn->prepare("
        SELECT id, content, category, color, posX, posY, votes 
        FROM brainstorm_message 
        WHERE space_id = (
            SELECT id FROM brainstorm_space WHERE created_by=? LIMIT 1
        )
        ORDER BY created_at DESC
    ");
    $stmt->bind_param("i", $author_id);

    $stmt->execute();
    $res = $stmt->get_result();

    $arr = [];
    while($row = $res->fetch_assoc()) $arr[] = $row;
    echo json_encode($arr);

// ===== 메시지 삭제 =====
} else if($action === "delete"){
    $message_id = $_POST['message_id'] ?? 0;
    $stmt = $conn->prepare("
        DELETE FROM brainstorm_message 
        WHERE id=? AND author_id=?
    ");
    $stmt->bind_param("ii", $message_id, $author_id);
    if($stmt->execute()) echo json_encode(["status"=>"success"]);
    else echo json_encode(["status"=>"error","msg"=>"삭제 실패"]);

// ===== 위치 업데이트 =====
} else if($action === "update_pos"){
    $message_id = $_POST['message_id'] ?? 0;
    $posX = $_POST['posX'] ?? 0;
    $posY = $_POST['posY'] ?? 0;

    $stmt = $conn->prepare("
        UPDATE brainstorm_message 
        SET posX=?, posY=? 
        WHERE id=? AND author_id=?
    ");
    $stmt->bind_param("iiii", $posX, $posY, $message_id, $author_id);
    $stmt->execute();
    echo json_encode(["status"=>"success"]);

} else {
    echo json_encode(["status"=>"error","msg"=>"잘못된 action"]);
}
?>
