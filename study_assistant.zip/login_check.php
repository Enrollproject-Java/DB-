<?php
include 'db_connect.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nickname = $_POST['id'];        // HTML의 name="id" 입력값
    $password = $_POST['password'];

    // 닉네임으로 회원 검색
    $sql = "SELECT * FROM student WHERE name = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $nickname);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // 비밀번호 검증
        if (password_verify($password, $row['password'])) {
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['nickname'] = $row['name'];
            echo "<script>alert('로그인 성공'); location.href='Main_page.php';</script>";
        } else {
            echo "<script>alert('비밀번호가 일치하지 않습니다'); history.back();</script>";
        }
    } else {
        echo "<script>alert('존재하지 않는 닉네임입니다'); history.back();</script>";
    }

    $stmt->close();
    $conn->close();
}
?>
