<?php
include 'db_connect.php';
session_start();

// 로그인된 사용자 ID (세션에서 가져옴)
$student_id = $_SESSION['student_id'] ?? 1; // 테스트용 기본값 1
$action = $_POST['action'] ?? '';

if ($action === 'save') {
    $title = $_POST['title'] ?? '';
    $content = $_POST['content'] ?? '';

    // 기존 노트 있으면 업데이트, 없으면 추가
    $stmt = $conn->prepare("SELECT id FROM note WHERE student_id=? AND title=?");
    $stmt->bind_param("is", $student_id, $title);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($note_id);
        $stmt->fetch();
        $update = $conn->prepare("UPDATE note SET content=? WHERE id=?");
        $update->bind_param("si", $content, $note_id);
        $update->execute();
        echo "updated";
    } else {
        $insert = $conn->prepare("INSERT INTO note (student_id, title, content) VALUES (?, ?, ?)");
        $insert->bind_param("iss", $student_id, $title, $content);
        $insert->execute();
        echo "created";
    }

} elseif ($action === 'load') {
    $title = $_POST['title'] ?? '';
    $stmt = $conn->prepare("SELECT content FROM note WHERE student_id=? AND title=?");
    $stmt->bind_param("is", $student_id, $title);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    echo $res['content'] ?? '';

} elseif ($action === 'delete') {
    $title = $_POST['title'] ?? '';
    $stmt = $conn->prepare("DELETE FROM note WHERE student_id=? AND title=?");
    $stmt->bind_param("is", $student_id, $title);
    echo $stmt->execute() ? "deleted" : "error";
}
?>
