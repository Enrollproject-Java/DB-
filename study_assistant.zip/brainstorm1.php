<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>브레인스토밍 보드</title>
    <link rel="stylesheet" href="brainstorm_style.css">
    <style>
/*  배경 */
.modal {
position: fixed;
top: 0;
left: 0;
width: 100%;
height: 100%;
background: rgba(0,0,0,0.4); /* 팝업 뒤 배경 */
display: flex;
align-items: center;
justify-content: center;
z-index: 200;
}
.modal.hidden {
  display: none;
}
.modal-content {
  background: #ffffff;
  padding: 25px 20px;
  border-radius: 12px;
  width: 300px;
  text-align: center;
  box-shadow: 0 4px 15px rgba(0,0,0,0.2);
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  color: #03396c;
}
.modal-content h3 {
  margin-bottom: 15px;
  font-size: 1.2rem;
  color: #03396c;
}
/* 팀 항목 */
.team-item {
  padding: 8px;
  margin: 6px 0;
  border: 1px solid #dff3ff;
  border-radius: 6px;
  cursor: pointer;
  background: #bad7f5;
  transition: all 0.2s ease;
}
.team-item:hover {
  background: #dee8ec;
  transform: scale(1.03);
}
/* 팀 추가 입력창 */
.team-input {
  width: 80%;
  padding: 6px 10px;
  margin-top: 12px;
  border: 1px solid #bad7f5;
  border-radius: 6px;
  outline: none;
}
.team-input:focus {
  border-color: #00bfff;
  /* box-shadow: 0 0 5px #00bfff; */
}
/* 팀 추가 버튼 */
.team-add-btn {
  margin-top: 10px;
  padding: 6px 12px;
  border: none;
  border-radius: 6px;
  background-color: #87cefa;
  color: rgb(31, 28, 28);
  /* font-weight: bold; */
  cursor: pointer;
  transition: all 0.2s ease;
}
.team-add-btn:hover {
  background-color: #92a2fd;
  transform: scale(1.05);
}
  </style>
</head>
<body>
  <header>
    <!-- 홈으로 이동, 메인페이지 링크 추가 -->
    <button onclick="location.href='Main_page.php'">Home</button>
    <h1>브레인스토밍 <span id="currentTeamName" style="font-size:1rem; color:#555; margin-left:10px;"></span></h1>
    <div class="user-area">
      <button id="userBtn">팀 선택</button>
    <div id="userMenu" class="user-menu hidden">
      <div class="menu-item">내 프로필</div>
      <div class="menu-item" id="teamSelectBtn">팀 선택</div>
      <div class="menu-item">팀원 추가</div>
    </div>
  </div>
  </header>
  <div class="input-area">
    <input type="text" id="ideaInput" placeholder="아이디어를 입력하세요..." />
    <select id="categorySelect">
      <option value="기본">카테고리 선택</option>
      <option value="아이디어">아이디어</option>
      <option value="문제점">문제점</option>
      <option value="해결방안">해결방안</option>
      <option value="기타">기타</option>
      <option value="__add__">+ 새 카테고리 추가</option>
    </select>
    <!-- 색상 선택 -->
  <select id="colorSelect">
    <option value="" selected>색상 선택</option>
    <option value="color-yellow" style="background:#fff3bf;"></option>
    <option value="color-blue" style="background:#a5d8ff;"></option>
    <option value="color-green" style="background:#b2f2bb;"></option>
    <option value="color-purple" style="background:#d0bfff;"></option>
    <option value="color-pink" style="background:#fcc2d7;"></option>
    <option value="color-teal" style="background:#96f2d7;"></option>
  </select>
  <button id="addIdeaBtn">추가</button>
  </div>
  <!-- 카테고리 선택 -->
  <div class="category-tabs" id="categoryTabs">
    <div class="tab active" data-category="아이디어">아이디어</div>
    <div class="tab" data-category="문제점">문제점</div>
    <div class="tab" data-category="해결방안">해결방안</div>
    <div class="tab" data-category="기타">기타</div>
  </div>
  <div class="board-container" id="board"></div>
  <!-- 팀 선택 모달 -->
  <div id="teamModal" class="modal hidden">
    <div class="modal-content">
      <h3>팀 목록</h3>
      <div id="teamList"></div>
      <input id="newTeamName" class="team-input" placeholder="새 팀 이름 입력" />
      <button id="addTeamBtn" class="team-add-btn">팀 추가</button>
    </div>
  </div>
  <!-- ----------------------------------------------script------------------------------------------------------->
<script>
const board = document.getElementById("board");
const addBtn = document.getElementById("addIdeaBtn");
const input = document.getElementById("ideaInput");
const categorySelect = document.getElementById("categorySelect");
const tabsContainer = document.getElementById("categoryTabs");
const colorSelect = document.getElementById("colorSelect");

let currentCategory = "아이디어";
const author_id = 1; // 로그인 유저 ID (예시)
let currentTeam = localStorage.getItem("currentTeam") || "사용자";

// ===== 팀/유저 UI =====
const userBtn = document.getElementById("userBtn");
const userMenu = document.getElementById("userMenu");
userBtn.addEventListener("click", () => userMenu.classList.toggle("hidden"));
window.addEventListener("click", e => {
  if(!userMenu.contains(e.target) && e.target !== userBtn) userMenu.classList.add("hidden");
});

// ===== 탭/카테고리 추가 =====
function refreshTabListeners() {
  document.querySelectorAll(".tab").forEach(tab => {
    tab.onclick = () => {
      document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
      tab.classList.add("active");
      currentCategory = tab.dataset.category;
      loadIdeas(); // DB에서 다시 불러오기
    };
  });
}
refreshTabListeners();

categorySelect.addEventListener("change", () => {
  if(categorySelect.value === "__add__"){
    const newCat = prompt("새 카테고리 이름을 입력하세요:");
    if(!newCat){ categorySelect.value = currentCategory; return; }
    // select에 추가
    const option = document.createElement("option");
    option.value = newCat; option.textContent = newCat;
    categorySelect.insertBefore(option, categorySelect.lastElementChild);
    categorySelect.value = newCat;
    // 탭에도 추가
    const tab = document.createElement("div");
    tab.className = "tab"; tab.dataset.category = newCat; tab.textContent = newCat;
    tabsContainer.appendChild(tab);
    refreshTabListeners();
  }
});

// ===== 아이디어 추가 =====
addBtn.addEventListener("click", addIdea);
input.addEventListener("keypress", e => { if(e.key==="Enter") addIdea(); });

async function addIdea(){
  const text = input.value.trim();
  const cat = categorySelect.value;
  const color = colorSelect.value || "color-yellow";
  if(!text) return alert("아이디어를 입력하세요.");
  if(cat==="기본") return alert("카테고리를 선택하세요.");

  const posX = 100 + Math.random()*600;
  const posY = 100 + Math.random()*400;

  const res = await fetch("brainstorm_api.php", {
    method:"POST",
    headers: {'Content-Type':'application/x-www-form-urlencoded'},
    body: new URLSearchParams({
      action:"add",
      author_id,
      content:text,
      category:cat,
      color,
      posX,
      posY
    })
  });

const data = await res.json();
if (data.status === "success") {
  input.value = "";
  await loadIdeas(); // DB에 추가 후 즉시 새로고침
} else {
  alert("추가 실패: " + (data.msg || "오류 발생"));
}

}

// ===== 아이디어 불러오기 =====
async function loadIdeas(){
  const res = await fetch("brainstorm_api.php", {
    method:"POST",
    headers:{'Content-Type':'application/x-www-form-urlencoded'},
    body: new URLSearchParams({action:"load", author_id})
  });
  const ideas = await res.json();
  renderIdeas(ideas);
}

// ===== 아이디어 렌더링 =====
function renderIdeas(ideas){
  board.innerHTML = "";
  const filtered = ideas.filter(i => i.category === currentCategory);
  
  filtered.forEach(idea => {
    const note = document.createElement("div");
    note.className = "sticky-note "+idea.color;
    note.style.top = idea.posY+"px";
    note.style.left = idea.posX+"px";
    note.innerHTML = `
      <div>${idea.content}</div>
      <div class="category-tag">#${idea.category}</div>
      <div class="delete-btn">삭제</div>
    `;
    note.dataset.id = idea.id;

    // ===== 우클릭 두 번으로 삭제 =====
note.addEventListener("contextmenu", async e => {
  e.preventDefault();

  // note마다 자체 클릭 횟수 기억
  note._clicks = (note._clicks || 0) + 1;

  if (note._clicks === 2) {
    const res = await fetch("brainstorm_api.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        action: "delete",
        message_id: idea.id,
        author_id
      })
    });

    const json = await res.json().catch(() => null);
    if (json && json.status === "success") {
      note.remove(); // 화면에서 삭제
    } else {
      alert("삭제 실패: " + (json?.msg || "DB 오류"));
    }

    note._clicks = 0; // 초기화
  }
  

  // 1초 지나면 자동 리셋
  setTimeout(() => note._clicks = 0, 1000);
});
    // ===== 우클릭 두 번으로 삭제 =====
note.addEventListener("contextmenu", async e => {
  e.preventDefault();

  // note마다 자체 클릭 횟수 기억
  note._clicks = (note._clicks || 0) + 1;

  if (note._clicks === 2) {
    const res = await fetch("brainstorm_api.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        action: "delete",
        message_id: idea.id,
        author_id
      })
    });

    const json = await res.json().catch(() => null);
    if (json && json.status === "success") {
      note.remove(); // 화면에서 삭제
    } else {
      alert("삭제 실패: " + (json?.msg || "DB 오류"));
    }

    note._clicks = 0; // 초기화
  }

  // 1초 지나면 자동 리셋
  setTimeout(() => note._clicks = 0, 1000);
});

    // 삭제
    note.querySelector(".delete-btn").addEventListener("click", async ()=>{
      const res = await fetch("brainstorm_api.php", {
        method:"POST",
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:new URLSearchParams({action:"delete", message_id:idea.id})
      });

    // 우클릭 시 삭제 버튼 표시/숨김 토글
    
    

const resData = await res.json();
if (resData.status === "success") {
  loadIdeas(); // 삭제 즉시 새로고침
} else {
  alert("삭제 실패: " + (resData.msg || "오류 발생"));
}
  note.addEventListener("contextmenu", e => {
    e.preventDefault();
    e.stopPropagation();
    note.classList.toggle("show-delete");
  });

    });

    // 드래그
    makeDraggable(note, idea);

    board.appendChild(note);
  });
}

// ===== 드래그 기능 =====
function makeDraggable(el, idea){
  let isDragging=false, offsetX, offsetY;
  el.addEventListener("mousedown", e=>{
    if(e.target.classList.contains("delete-btn")) return;
    isDragging=true;
    offsetX = e.clientX - el.offsetLeft;
    offsetY = e.clientY - el.offsetTop;
    el.style.zIndex=1000;
  });
  window.addEventListener("mousemove", e=>{
    if(!isDragging) return;
    el.style.left = `${e.clientX-offsetX}px`;
    el.style.top = `${e.clientY-offsetY}px`;
  });
  window.addEventListener("mouseup", async e=>{
    if(isDragging){
      isDragging=false;
      el.style.zIndex=1;
      // DB에 위치 업데이트
      const res = await fetch("brainstorm_api.php", {
        method:"POST",
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:new URLSearchParams({
          action:"update_pos",
          message_id:idea.id,
          posX:el.offsetLeft,
          posY:el.offsetTop
        })
      });
      await res.text();
    }
  });
}

// board 전체 우클릭 이벤트 막기 방지
document.getElementById("board").addEventListener("contextmenu", e => {
  // 아무것도 하지 않음 (note 자체에서 처리하게)
}, true);

// 초기 로딩
loadIdeas();
</script>
