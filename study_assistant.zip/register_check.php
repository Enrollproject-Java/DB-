<?php
include 'db_connect.php'; // DB 연결

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nickname = $_POST['nickname'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // 비밀번호 암호화

    $sql = "INSERT INTO student (name, email, password) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $nickname, $email, $password);

    if ($stmt->execute()) {
        echo "<script>alert('회원가입 성공'); location.href='login_page.html';</script>";
    } else {
        echo "<script>alert('회원가입 실패'); history.back();</script>";
    }

    $stmt->close();
    $conn->close();
}
?>
